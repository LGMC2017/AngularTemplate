package model;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class LoginDAO {
	
	private Session sesion;
	private Transaction tx;
	

}
