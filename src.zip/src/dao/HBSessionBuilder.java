package dao;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HBSessionBuilder {
	
	 private static SessionFactory session;
	 
	 
	 public static SessionFactory getSessionFactory() {
		 return session;
	 }
	 
	 static {
		 try {
			 session = new Configuration().configure().buildSessionFactory();
		 }
		 catch (HibernateException hex) {
			 hex.printStackTrace();
		 }
	 }
	 
}
