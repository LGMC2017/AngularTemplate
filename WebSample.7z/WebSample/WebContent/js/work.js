onmessage = function(e) {
  //console.log('Message received from main script');
  var workerResult = 'Result: ' + (e.data);
  var paused = e.data;
  //console.log('Posting message back to main script');
  //postMessage(workerResult);
  var c = setInterval(
		  () => { 
			  //if(!paused) {
				  console.log(workerResult)
			  //}
	}, 1000);
  postMessage(c);
}