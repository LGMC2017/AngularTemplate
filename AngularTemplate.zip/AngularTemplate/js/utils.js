﻿String.prototype.replaceParamToken = function (token, value) {
    var strtoken = '<^' + token + '^>';
    return this.replace(strtoken, value);
}
