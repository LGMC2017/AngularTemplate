/**
 * by GABO 2018
 */
var refreshIntervalId = 0;
var paused = false;
var $table;
$(function(){
	$table = $("#tablenames>tbody");
	$table.empty();
	teammates.forEach(function (mate, k) {
		$table.append("<tr>"
				+"<td style='width: 10%'>"+(k+1)+"</td>"
				+"<td style='width: 40%'>"+mate+"</td>"
				+"<td style='width: 50%' class='placeholder'></td>"
			+"</tr>");
	});
	refreshIntervalId =	window.setInterval(function(){
		showValues();
	}, 40);
});
function startGame() {
	if(refreshIntervalId == 0) {
		refreshIntervalId =	window.setInterval(function(){
			showValues();
		}, 10);
	}
}
function toggleAnim(e) {
	paused = !paused;
	if(paused) {
		$(e).text('START AGAIN!');
		clearInterval(refreshIntervalId);
	}
	else {
		$(e).text('SHOW MATCHES!');
		refreshIntervalId = 0;
		startGame();
	}
}
function showValues() {
	$($table).children("tr").each(function() {
		$this = $(this);
		$this.find(".placeholder").html(getCharacter()) 
	});
}
function getCharacter() {
	item = Math.floor((Math.random() * 1251) + 1);
	return characters[item] 
}